module.exports = {
	plugins: {
		'css-mqpacker': {sort: true},
		autoprefixer: {browsers: '> 1%, last 2 versions'}
	}
};
